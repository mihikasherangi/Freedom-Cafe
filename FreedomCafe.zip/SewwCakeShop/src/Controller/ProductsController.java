/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import javax.swing.JOptionPane;

/**
 *
 * @author Thenali manathunga
 */
public class ProductsController {

    
    public static void Products(String ID, String Category, String Flavour, String Quantity, String Price) {
        new Model.AddProducts().Products(ID, Category, Flavour, Quantity, Price);
        JOptionPane.showMessageDialog(null, "New product has been inserted", "Successful", JOptionPane.INFORMATION_MESSAGE);
    }
}

