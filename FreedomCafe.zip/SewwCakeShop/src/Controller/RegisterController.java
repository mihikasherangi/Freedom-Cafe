/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import javax.swing.JOptionPane;

/**
 *
 * @author Thenali manathunga
 */
public class RegisterController {
    
    public static void Register(String ID, String Category, String Name, String NICNumber, String ContactNumber, String Address, String Gender) {
        // Correct method call to match AddRecords method signature
        new Model.AddRecords().Records(ID, Category, Name, NICNumber,ContactNumber, Address, Gender);
        
        JOptionPane.showMessageDialog(null, "New Record has been inserted", "Successful", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // Remove unsupported method
    // public static void Records(String text, String text0, String text1, String text2, String text3) {
    //     throw new UnsupportedOperationException("Not supported yet.");
    // }

    public static void Records(String text, String text0, String text1, String text2, String text3) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static void Register(String text, String text0, String text1, String text2, String text3) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

